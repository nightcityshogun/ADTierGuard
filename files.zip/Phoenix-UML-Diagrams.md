# Phoenix UML Architecture Diagrams (Mermaid Format)

## 1. System Context Diagram

```mermaid
C4Context
    title Phoenix System Context
    
    Person(responder, "Incident Responder", "Security analyst executing IR procedures")
    
    System(phoenix, "Phoenix Module", "Identity IR Toolkit - 150k lines PowerShell")
    
    System_Ext(ad, "Active Directory", "Forest/Domain Controllers")
    System_Ext(graph, "Microsoft Graph API", "Entra ID Management")
    System_Ext(exo, "Exchange Online", "Role Management")
    System_Ext(arm, "Azure ARM", "RBAC Management")
    
    Rel(responder, phoenix, "Uses", "GUI/CLI")
    Rel(phoenix, ad, "LDAP/ADSI", "389/636")
    Rel(phoenix, graph, "REST API", "HTTPS")
    Rel(phoenix, exo, "REST API", "HTTPS")
    Rel(phoenix, arm, "REST API", "HTTPS")
```

## 2. Component Architecture

```mermaid
graph TB
    subgraph Presentation["Presentation Layer"]
        GUI[Invoke-WinUI3<br/>22,000 lines]
        Dashboard[Dashboard Panel]
        ADPanel[AD Platform]
        AzurePanel[Azure Platform]
        EvidencePanel[Evidence Collection]
    end
    
    subgraph Business["Business Logic Layer (21 Public Functions)"]
        subgraph ADRecovery["AD Recovery"]
            GetADIOE[Get-ADIOE<br/>2,095 lines]
            ControlDisp[Invoke-ControlDisposition<br/>1,238 lines]
            FSMOSeize[Invoke-FSMORoleSeizure]
            MetaClean[Invoke-MetadataCleanup]
            SysvolRest[Invoke-SysvolRestore]
            DNSClean[Invoke-DnsCleanup]
            TrustReset[Invoke-TrustPasswordReset]
        end
        
        subgraph AzureRecovery["Azure/Entra Recovery"]
            BreakGlass[Invoke-BreakGlass]
            EntraDisp[Invoke-EntraDisposition]
            RBACDisp[Invoke-AzureRBACDisposition]
            GuardRails[Invoke-GuardRails]
            RiskyApp[Invoke-RiskyAppReview]
            ExchDisp[Invoke-ExchangeDisposition]
        end
        
        subgraph CredMgmt["Credential Management"]
            Krbtgt[Set-KrbtgtPassword]
            DCAcct[Set-DcAccountPassword]
            BuiltinAdmin[Set-BuiltinAdminPassword]
            GMSA[Set-GMSA]
            MassReset[Invoke-MassPasswordReset]
        end
    end
    
    subgraph Data["Data Access Layer (12 Private Functions)"]
        ConnectAz[Connect-MicrosoftAzure]
        ForestInfo[Get-ForestInfo]
        GraphHelper[Invoke-GraphHelper]
        ADData[Get-ADData]
        Logger[Write-IdentIRLog]
    end
    
    GUI --> Dashboard
    GUI --> ADPanel
    GUI --> AzurePanel
    GUI --> EvidencePanel
    
    ADPanel --> ADRecovery
    AzurePanel --> AzureRecovery
    EvidencePanel --> GetADIOE
    
    ADRecovery --> Data
    AzureRecovery --> Data
    CredMgmt --> Data
```

## 3. IOE Scanner Flow

```mermaid
flowchart TD
    Start([Start IOE Scan]) --> Input[/DC List + Credentials/]
    Input --> CreatePool[Create Runspace Pool<br/>n = DC count]
    CreatePool --> LoadCatalog[Load IOE Catalog<br/>85 checks, 9 categories]
    
    LoadCatalog --> QueueJobs[Queue DC Jobs]
    QueueJobs --> ParallelScan{Parallel Scan<br/>Each DC}
    
    ParallelScan --> |DC 1| Scan1[Execute IOE Checks]
    ParallelScan --> |DC 2| Scan2[Execute IOE Checks]
    ParallelScan --> |DC n| ScanN[Execute IOE Checks]
    
    Scan1 --> Aggregate[Aggregate Findings]
    Scan2 --> Aggregate
    ScanN --> Aggregate
    
    Aggregate --> Stats[Calculate Statistics]
    Stats --> Export{Export Files?}
    Export --> |Yes| CreateExport[Create CSV + JSON<br/>ZIP Archive + SHA256]
    Export --> |No| Result
    CreateExport --> Result[/IOEResult Object/]
    Result --> UpdateDash[Update Dashboard]
    UpdateDash --> End([Complete])
    
    subgraph IOE Categories
        Kerberos[Kerberos - 12 checks]
        Password[Password - 15 checks]
        Privileged[Privileged - 10 checks]
        Delegation[Delegation - 8 checks]
        Certificate[Certificate - 6 checks]
        Domain[Domain - 14 checks]
        DC[DC - 12 checks]
        GPO[GPO - 10 checks]
        Objects[Objects - 8 checks]
    end
```

## 4. Azure Authentication Flow

```mermaid
sequenceDiagram
    participant User
    participant Phoenix
    participant Azure as Azure AD
    participant Browser
    
    User->>Phoenix: Connect-MicrosoftAzure
    Phoenix->>Azure: POST /devicecode
    Azure-->>Phoenix: device_code, user_code
    Phoenix->>User: Display: "Enter code XXXX at microsoft.com/devicelogin"
    
    User->>Browser: Navigate to URL
    Browser->>Azure: Enter code
    User->>Browser: Authenticate + Consent
    
    loop Poll for token
        Phoenix->>Azure: POST /token (device_code)
        Azure-->>Phoenix: authorization_pending
    end
    
    Azure-->>Phoenix: access_token, refresh_token
    Phoenix->>User: Authentication complete
    Phoenix->>Azure: GET /me (validate)
    Azure-->>Phoenix: User profile
```

## 5. Task Execution State Machine

```mermaid
stateDiagram-v2
    [*] --> Locked: Prerequisites not met
    
    Locked --> Unlocked: Prerequisites complete
    
    Unlocked --> Simulating: User clicks WhatIf
    Unlocked --> Confirming: User clicks Execute
    
    Simulating --> Unlocked: Simulation complete
    
    Confirming --> Executing: User confirms
    Confirming --> Unlocked: User cancels
    
    Executing --> Completed: Success
    Executing --> Failed: Error
    
    Failed --> Unlocked: User acknowledges
    
    Completed --> [*]
```

## 6. IR Workflow Activity

```mermaid
flowchart TB
    Start([IR Triggered]) --> Launch[Launch Phoenix GUI]
    
    Launch --> Phase1
    Launch --> AzureTrack
    
    subgraph Phase1["Phase 1: CONTAIN"]
        Discover[1. Discover Forest<br/>Get-ForestInfo]
        IOE[2. Collect IOE<br/>Get-ADIOE]
        Control[3. Control Disposition<br/>Invoke-ControlDisposition]
        
        Discover --> IOE --> Control
    end
    
    subgraph AzureTrack["Azure Parallel Track"]
        Auth[1. Device Code Auth]
        BG[2. Create Break Glass]
        EntraD[3. Entra Disposition]
        GR[4. Deploy Guard Rails]
        
        Auth --> BG --> EntraD --> GR
    end
    
    Phase1 --> Phase2
    
    subgraph Phase2["Phase 2: ERADICATE"]
        KRBTGT[4. KRBTGT Rotation]
        Creds[5. Credential Rotation<br/>DC, Admin, Trust, GMSA]
        Meta[6. Metadata Cleanup]
        
        KRBTGT --> Creds --> Meta
    end
    
    Phase2 --> Phase3
    AzureTrack --> Phase3
    
    subgraph Phase3["Phase 3: RECOVER"]
        FSMO[7. FSMO Seizure]
        DNS[8. DNS Cleanup]
        SYSVOL[9. SYSVOL Restore]
        
        FSMO --> DNS --> SYSVOL
    end
    
    Phase3 --> Report[Generate Outbrief Report]
    Report --> End([Environment Recovered])
```

## 7. Class Diagram - DC Information

```mermaid
classDiagram
    class IsolatedDCInfo {
        +String Type
        +String Domain
        +String DomainSid
        +String Site
        +String Name
        +String FQDN
        +Boolean IsGC
        +Boolean IsRODC
        +Boolean Online
        +Boolean IsPdcRoleOwner
        +String IPv4Address
        +TestConnectivity() Boolean
        +GetRootDSE() DirectoryEntry
    }
    
    class ForestInventory {
        +IsolatedDCInfo[] DomainControllers
        +String ForestRootDomain
        +String[] Domains
        +Int OnlineCount
        +Int TotalCount
        +GetOnlineDCs() IsolatedDCInfo[]
        +GetDomainPDC(domain) IsolatedDCInfo
        +GroupByDomain() Hashtable
    }
    
    class IOEResult {
        +Boolean Success
        +String RunId
        +DateTime Timestamp
        +String Duration
        +Int TotalFindings
        +Int CriticalCount
        +Int HighCount
        +Int MediumCount
        +String[] DomainsScanned
        +Hashtable Categories
        +IOEFinding[] Findings
        +String ZipPath
        +String ZipHash
    }
    
    class IOEFinding {
        +String IOE
        +String Category
        +String Severity
        +String Name
        +String Domain
        +String DC
        +String ObjectDN
        +String Details
    }
    
    ForestInventory "1" --> "*" IsolatedDCInfo
    IOEResult "1" --> "*" IOEFinding
```

## 8. Deployment Diagram

```mermaid
graph TB
    subgraph Workstation["IR Workstation (Isolated VLAN)"]
        PS[PowerShell 5.1+]
        WPF[WPF GUI]
        DLL[Wpf.Ui.dll]
        Logs[Log Files<br/>%LOCALAPPDATA%\Phoenix]
    end
    
    subgraph AD["Active Directory Environment"]
        DC1[Domain Controller 1]
        DC2[Domain Controller 2]
        DCn[Domain Controller n]
        DNS[DNS Servers]
        SYSVOL[SYSVOL/DFSR]
    end
    
    subgraph Cloud["Microsoft Cloud"]
        Graph[graph.microsoft.com]
        Login[login.microsoftonline.com]
        ARM[management.azure.com]
        EXO[outlook.office365.com]
    end
    
    Workstation -->|LDAP 389/636| AD
    Workstation -->|HTTPS 443| Cloud
```

---

## Code Statistics

| Component | Lines | Files |
|-----------|-------|-------|
| GUI Layer | ~110,000 | 6 |
| Public Functions | ~17,500 | 21 |
| Private Functions | ~23,000 | 12 |
| **Total** | **~150,700** | **39** |

---

*Phoenix - Identity Incident Response Toolkit*
*© 2025 NCS Dojo*
