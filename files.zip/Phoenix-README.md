# 🔥 Phoenix - Identity Incident Response Toolkit

<p align="center">
  <img src="phoenix/private/ADTierGuard.png" alt="Phoenix Logo" width="200"/>
</p>

<p align="center">
  <strong>Enterprise-Grade Active Directory & Azure/Entra ID Recovery Platform</strong>
</p>

<p align="center">
  <a href="#features">Features</a> •
  <a href="#installation">Installation</a> •
  <a href="#quick-start">Quick Start</a> •
  <a href="#modules">Modules</a> •
  <a href="#documentation">Documentation</a>
</p>

---

## 📋 Overview

**Phoenix** is a comprehensive PowerShell-based incident response toolkit designed for enterprise identity infrastructure recovery. It provides guided workflows for remediating compromised Active Directory and Azure/Entra ID environments through a modern WPF graphical interface.

### Key Capabilities

| Domain | Capabilities |
|--------|-------------|
| **Active Directory** | Forest discovery, privileged account remediation, FSMO seizure, metadata cleanup, SYSVOL restore, DNS cleanup, credential rotation |
| **Azure/Entra ID** | Break glass accounts, role disposition, Conditional Access policies, risky app review, RBAC management |
| **Evidence Collection** | AD Indicators of Exposure (IOE) scanning, audit log collection, compliance reporting |
| **Credential Management** | KRBTGT rotation, trust password reset, GMSA rotation, mass password reset |

---

## ✨ Features

### 🖥️ Modern GUI Interface
- **WPF-based UI** using Wpf.Ui Fluent design library
- **Step-by-step guided workflows** with progress indicators
- **Simulation mode (WhatIf)** for safe pre-validation
- **Dark/Light theme support**
- **Real-time logging** and detailed reporting

### 🔒 Active Directory Recovery
- **Forest Discovery** - Parallel DC enumeration with connectivity testing
- **Control Disposition** - Privileged account and ACL remediation
- **FSMO Role Seizure** - Safe role transfer with RID pool management
- **Metadata Cleanup** - Orphaned DC object removal
- **SYSVOL Restore** - Authoritative/non-authoritative restore (DFSR/FRS)
- **DNS Cleanup** - Stale record detection and removal
- **Trust Password Reset** - Inter/intra-forest trust rotation

### ☁️ Azure/Entra ID Recovery
- **Break Glass Accounts** - Emergency admin provisioning
- **Entra Disposition** - Privileged role audit and cleanup
- **Guard Rails** - Conditional Access policy deployment
- **Risky App Review** - Service principal permission analysis
- **RBAC Disposition** - Azure role assignment management
- **Exchange Disposition** - Exchange Online role cleanup

### 🔑 Credential Rotation
- **KRBTGT Password** - Two-cycle rotation for Golden Ticket mitigation
- **DC Account Passwords** - Machine account credential rotation
- **Built-in Admin** - RID 500 account password reset
- **GMSA Rotation** - Group Managed Service Account recreation
- **Mass Password Reset** - Bulk user credential rotation

### 📊 Evidence Collection
- **AD IOE Scanner** - 85+ security indicator checks across 9 categories
- **Graph API Integration** - Directory audit and sign-in log collection
- **Management API Access** - Exchange, SharePoint, General audit logs
- **Automated Reporting** - CSV/JSON export with SHA256 verification

---

## 📦 Installation

### Prerequisites

| Requirement | Details |
|-------------|---------|
| **Operating System** | Windows 10/11 or Windows Server 2016+ |
| **PowerShell** | Version 5.1 or PowerShell 7+ |
| **Privileges** | Run as Administrator |
| **Architecture** | x64 or x86 (ARM not supported for WPF) |

### Install Steps

1. **Download** the Phoenix module package
2. **Extract** to a local directory
3. **Import** the module:

```powershell
# Navigate to the phoenix directory
cd C:\path\to\phoenix

# Import the module
Import-Module .\phoenix.psd1 -Force

# Launch the GUI
Invoke-WinUI3
```

### Network Requirements

| Protocol | Port | Destination | Purpose |
|----------|------|-------------|---------|
| LDAP | 389 | Domain Controllers | AD queries |
| LDAPS | 636 | Domain Controllers | Secure AD ops |
| HTTPS | 443 | graph.microsoft.com | Entra ID |
| HTTPS | 443 | login.microsoftonline.com | Auth |
| HTTPS | 443 | management.azure.com | Azure RBAC |
| DNS | 53 | DNS Servers | Resolution |

---

## 🚀 Quick Start

### Launch the GUI

```powershell
# Import and launch
Import-Module .\phoenix.psd1 -Force
Invoke-WinUI3
```

### Command-Line Usage

Each function can be used independently:

```powershell
# Discover forest topology
$forestInfo = Get-ForestInfo -Credential $cred

# Run IOE security scan
$ioeResults = Get-ADIOE -IsolatedDCList $forestInfo -ExportFiles

# Perform control disposition (WhatIf mode)
Invoke-ControlDisposition -IsolatedDCList $forestInfo -WhatIf

# Execute KRBTGT rotation
Set-KrbtgtPassword -IsolatedDCList $forestInfo -Execute
```

---

## 📚 Modules

### Public Functions (21)

#### Active Directory Recovery

| Function | Description |
|----------|-------------|
| `Get-ADIOE` | AD Indicators of Exposure scanner - 85 security checks across 9 categories |
| `Invoke-ControlDisposition` | Privileged account and ACL remediation to baseline |
| `Invoke-FSMORoleSeizure` | FSMO role seizure with RID pool bump |
| `Invoke-MetadataCleanup` | Orphaned DC metadata removal |
| `Invoke-SysvolRestore` | Authoritative SYSVOL restore (DFSR/FRS) |
| `Invoke-DnsCleanup` | Stale DNS record detection and cleanup |
| `Invoke-TrustPasswordReset` | Trust password rotation or orphan deletion |

#### Azure/Entra ID Recovery

| Function | Description |
|----------|-------------|
| `Invoke-BreakGlass` | Emergency admin account creation |
| `Invoke-EntraDisposition` | Entra ID privileged role disposition |
| `Invoke-AzureRBACDisposition` | Azure RBAC role assignment management |
| `Invoke-GuardRails` | Conditional Access policy deployment |
| `Invoke-RiskyAppReview` | Service principal permission analysis |
| `Invoke-ExchangeDisposition` | Exchange Online role cleanup |
| `Invoke-DomainFederationReview` | Custom domain federation review |
| `Set-AuthorizationPolicy` | Entra authorization policy hardening |
| `Set-OnPremisesSyncDisabled` | Disable AD Connect synchronization |

#### Credential Management

| Function | Description |
|----------|-------------|
| `Set-KrbtgtPassword` | KRBTGT password rotation (2 cycles) |
| `Set-DcAccountPassword` | DC machine account password reset |
| `Set-BuiltinAdminPassword` | RID 500 administrator password reset |
| `Set-GMSA` | GMSA account rotation and KDS key recreation |
| `Invoke-MassPasswordReset` | Bulk user password reset |

### Private Functions (12)

| Function | Description |
|----------|-------------|
| `Connect-MicrosoftAzure` | Device code authentication for Azure/Entra |
| `Get-ForestInfo` | Parallel forest/DC discovery |
| `Invoke-GraphHelper` | MS Graph API wrapper with pagination |
| `Write-IdentIRLog` | Timestamped logging framework |
| `New-Password` | Cryptographic password generator |
| `Get-UserPrivileges` | Privilege verification |
| `Get-BuiltInAdmin` | RID 500 account enumeration |
| `Get-DeleteProtection` | Object deletion protection check |
| `Get-ADData` | LDAP query helper |
| `Get-ReverseZoneIPv4` | IPv4 reverse DNS zone calculation |
| `Get-ReverseZoneIPv6` | IPv6 reverse DNS zone calculation |
| `Convert-SidToLdapFilter` | SID to LDAP filter conversion |

---

## 🛡️ AD IOE Scanner

The `Get-ADIOE` function performs comprehensive security analysis across 9 categories:

### IOE Categories

| Category | Checks | Description |
|----------|--------|-------------|
| **Kerberos** | 12 | Delegation, SPN, encryption settings |
| **Password** | 15 | Policy, expiration, reversible encryption |
| **Privileged** | 10 | Admin groups, protected users, AdminSDHolder |
| **Delegation** | 8 | Constrained/unconstrained delegation |
| **Certificate** | 6 | PKI, certificate template risks |
| **Domain** | 14 | Functional level, trusts, schema |
| **DC** | 12 | Configuration, services, security |
| **GPO** | 10 | Policy settings, inheritance |
| **Objects** | 8 | Stale accounts, GMSA, computer objects |

### Sample Output

```
Get-ADIOE v5.0 - 85 IOE Checks - Run ID: 635aa600
Scanning 6 DC(s) across 4 domain(s)
Categories: All
Using 6 parallel runspaces

═══════════════════════════════════════════════════════
  AD IOE Scan Complete
═══════════════════════════════════════════════════════
  Run ID:      635aa600
  Duration:    00:00:02
  DCs Scanned: 6
  Domains:     praevia.local, child.praevia.local, fabrikam.local
───────────────────────────────────────────────────────
  Total Findings: 240
    Critical:      54
    Warning:       161
    Informational: 25
```

---

## 🏗️ Architecture

### Module Structure

```
phoenix/
├── phoenix.psd1                    # Module manifest
├── phoenix.psm1                    # Module loader
├── eula.txt                        # License
│
├── private/                        # Internal functions
│   ├── Connect-MicrosoftAzure.ps1  # Azure authentication
│   ├── Get-ForestInfo.ps1          # DC discovery
│   ├── Invoke-WinUI3.ps1           # Main GUI (22,000 lines)
│   ├── Write-IdentIRLog.ps1        # Logging
│   ├── Wpf.Ui.dll                  # WPF UI library
│   └── *.png                       # UI assets
│
└── public/                         # Exported functions
    ├── Get-ADIOE.ps1               # IOE scanner
    ├── Invoke-ControlDisposition.ps1
    ├── Invoke-BreakGlass.ps1
    └── ... (21 functions)
```

### Code Statistics

| Component | Lines | Files |
|-----------|-------|-------|
| GUI Layer | ~110,000 | 6 |
| Public Functions | ~17,500 | 21 |
| Private Functions | ~23,000 | 12 |
| **Total** | **~150,700** | **39** |

---

## 📊 Incident Response Workflow

### Phase 1: Contain

1. **Discover Forest** - Enumerate all domain controllers
2. **Collect IOE** - Scan for security indicators
3. **Control Disposition** - Lock down privileged access
4. **Disable Sync** - Stop AD Connect replication

### Phase 2: Eradicate

1. **KRBTGT Rotation** - Invalidate golden tickets
2. **Credential Reset** - Rotate all sensitive passwords
3. **Metadata Cleanup** - Remove compromised DC objects
4. **Trust Reset** - Rotate trust passwords

### Phase 3: Recover

1. **FSMO Seizure** - Restore operational roles
2. **DNS Cleanup** - Remove stale records
3. **SYSVOL Restore** - Restore GPO baseline
4. **Guard Rails** - Deploy protective policies

---

## 🔐 Security Considerations

### Credential Handling
- All credentials use `[PSCredential]` with `SecureString`
- Device code flow for Azure (no stored secrets)
- DPAPI encryption for saved state

### Execution Safety
- **WhatIf mode** available for all destructive operations
- Confirmation dialogs before execution
- Comprehensive logging of all actions
- Rollback information where applicable

### Network Security
- TLS 1.2+ enforced for all connections
- Certificate validation enabled
- No plaintext credential transmission

---

## 📝 Logging

All operations are logged to:

```
%LOCALAPPDATA%\Phoenix\phoenix_YYYYMMDD.log
```

Log format:
```
2025-01-02 10:15:30 [Info] Forest discovery complete: 6 online DC(s)
2025-01-02 10:15:35 [Info] Starting AD IOE collection (85 security checks)
2025-01-02 10:15:37 [Normal] IOE scan completed: 240 findings
```

---

## 🤝 MITRE ATT&CK Coverage

Phoenix addresses the following MITRE ATT&CK techniques:

| Technique | ID | Mitigation |
|-----------|-----|------------|
| Golden Ticket | T1558.001 | KRBTGT rotation |
| DCSync | T1003.006 | ACL remediation |
| AdminSDHolder | T1484.001 | Control disposition |
| Kerberoasting | T1558.003 | SPN review, encryption hardening |
| Pass-the-Hash | T1550.002 | Credential rotation |
| Account Manipulation | T1098 | Privileged role audit |

---

## 📄 License

Copyright © 2025 NCS Dojo. All rights reserved.

See [EULA.txt](EULA.txt) for license terms.

---

## 🆘 Support

For issues and feature requests, contact your NCS Dojo representative.

---

<p align="center">
  <strong>Phoenix - Rise from the Ashes</strong><br>
  <em>Identity Incident Response Toolkit</em>
</p>
